# Projeto Catálogo de filmes

Fonte:
https://fonts.google.com/specimen/Poppins

Fonte de ícones:
https://fonts.google.com/icons


## Subir o projeto

### XAMPP

Inicie o XAMPP com o Apache e MySQL.

Coloque a pasta do projeto no diretório htdocs.

### Docker

No diretório raiz do projeto execute o comando `docker-compose up -d` para executar o Apache e o MySQL.