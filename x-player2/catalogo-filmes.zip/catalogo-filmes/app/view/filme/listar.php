<?php

require_once __DIR__ . "/../../config/env.php";
require_once __DIR__ . "/../../config/Database.php";
require_once __DIR__ . "/../../model/Filme.php";

$filmeModel = new Filme($conn);
$filmes = $filmeModel->findAll();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filmes</title>

    <link rel="stylesheet" href="<?= BASE_URL ?>/public/css/style.css">
</head>

<body>
    <section class="container">
        <h2>Filmes</h2>

        <div class="acao-listagem">
            <a href="cadastrar.php">
                <button>
                    <span>Novo</span>
                    <span class="material-symbols-outlined">
                        add
                    </span>
                </button>
            </a>
        </div>

        <table class="table">
            <thead>
                <th>ID</th>
                <th>Título</th>
                <th>Ano</th>
                <th>Descrição</th>
                <th>Ação</th>
            </thead>
            <tbody>
                <?php foreach($filmes as $filme) { ?>
                <tr>
                    <td><?php echo $filme->id ?></td>
                    <td><?php echo $filme->titulo ?></td>
                    <td><?php echo $filme->ano ?></td>
                    <td><?php echo $filme->descricao ?></td>
                    <td>
                        <!-- GET para visualizar -->
                        <form action="visualizar.php" method="GET">
                            <input type="hidden" name="id" value="<?= $filme->id; ?>">
                            <button title="visualizar">
                                <span class="material-symbols-outlined">
                                    visibility
                                </span>
                            </button>
                        </form>

                        <!-- o POST é enviado ao arquivo de exclusão contendo a lógica -->
                        <form action="excluir.php" method="POST">
                            <input type="hidden" name="id" value="<?= $filme->id; ?>">
                            <button
                                title="excluir"
                                onclick="return confirm('Tem certeza que deseja excluir este filme?')">
                                <span class="material-symbols-outlined">
                                    delete
                                </span>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </section>

    <script src="<?= BASE_URL ?>/public/js/main.js" type="module" deferer></script>
</body>

</html>