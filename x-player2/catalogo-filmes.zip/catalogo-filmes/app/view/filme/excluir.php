<?php

require_once __DIR__ . "/../../config/Database.php";
require_once __DIR__ . "/../../model/Filme.php";

$filmeModel = new Filme($conn);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["id"])) {
        $id = $_POST["id"];

        $sucesso = $filmeModel->delete($id);

        if ($sucesso === TRUE) {
            header("Location: listar.php?mensagem=sucesso");
            exit;
        }
    }
}

header("Location: listar.php?mensagem=erro");