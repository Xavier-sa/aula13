<?php

require_once __DIR__ . "/../../config/env.php";
require_once __DIR__ . "/../../config/Database.php";
require_once __DIR__ . "/../../model/Filme.php";

$filmeModel = new Filme($conn);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["titulo"]) && isset($_POST["ano"])) {
        $filme = new Filme();
        $filme->titulo = $_POST["titulo"];
        $filme->ano = $_POST["ano"];
        $filme->descricao = $_POST["descricao"];

        $filme = $filmeModel->insert($filme);

        if (isset($filme)) {
            header("Location: visualizar.php?id=$filme->id");
            exit;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Filme</title>

    <link rel="stylesheet" href="<?= BASE_URL ?>/public/css/style.css">
</head>

<body>
    <section class="container">
        <form class="form" action="cadastrar.php" method="POST">
            <div class="form-header">
                <h2>Cadastro de filme</h2>
            </div>

            <div class="form-content">
                <div class="input-group required">
                    <label for="titulo">Título</label>
                    <input type="text" name="titulo" required>
                </div>

                <div class="input-group required">
                    <label for="ano">Ano</label>
                    <input type="number" name="ano" required>
                </div>

                <div class="input-group">
                    <label for="descricao">Descrição</label>
                    <textarea name="descricao" rows="5"></textarea>
                </div>
            </div>

            <div class="form-action acao-cadastro">
                <a href="listar.php">
                    <button type="button">Cancelar</button>
                </a>
                <button>Salvar</button>
            </div>
        </form>
    </section>
</body>

</html>