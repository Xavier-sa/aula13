<?php

define("BASE_URL", "http://localhost/catalogo-filmes")

?>