import { iniciarNotificacao } from "./notificacao";

iniciarNotificacao();