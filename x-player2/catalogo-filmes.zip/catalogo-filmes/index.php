<?php
header("Location: app/view/filme/listar.php");
?>
